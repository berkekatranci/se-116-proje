package item;

public  class Silahlar extends E�ya{
	
	private double hasar;
	

	public Silahlar(String isim, String a��klama, int de�er, int a��rl�k, double hasar) {
		super(isim, a��klama, de�er, a��rl�k);
		this.hasar = hasar;
	}
	
	//protected abstract void  g�ster();
	protected void g�ster() {
		 {
				System.out.println("isim: "+getIsim()+"\ta��klama: "+getA��klama()+"\tde�er: "+getDe�er()+"\ta��rl�k: "+getA��rl�k()+"\thasar: "+getHasar());
			}
		
	}
	public double getHasar() {
		return hasar;
	}
	public void setHasar(double hasar) {
		this.hasar = hasar;
	}
	
	
	
	

}

package item;

import java.security.SecureRandom;
import java.util.Scanner;

import karakterler.Canavar;

public class Sürücü {
	static Kılıç[] kılıçlar = { new Kılıç("Zülfikar", "Buz canlılarına karşı +5 hasar", 120, 4, 3),
			new Kılıç("RGB kılıç", "Düşmanın gözünü kamaştırır. +1 hasar", 3, 1, 6),
			new Kılıç("Gılışdar", "Liderlik vasfı yok", 40, 1, 4) };

	static Yay[] yaylar = { new Yay("Tatar Yayı", "Kıbrıs'tan Kırım'a kadar menzili vardır. +5 menzil", 120, 4, 3),
			new Yay("Sapan", "Fiiiiuuuu...", 3, 1, 5), new Yay("Yaycı Baba Yayı",
					"Yaycı Baba'nın sol böbreğindeki taşı düşürmeden önceki yaptığı son yay", 40, 1, 9) };

	static Balta[] baltalar = { new Balta("Kanlı Balta", "Buz canlılarına karşı +5 hasar", 120, 4, 4),
			new Balta("Zemzemle dövülmüş balta", "%6 şansla ruhları tek hamlede öldürür", 3, 1, 9),
			new Balta("Tor'un baltası", "Şimşekli mimşekli bir şeyler", 40, 1, 3) };

	static DeriZırh[] deriZırhlar = { new DeriZırh("Fare derisinden zırh", "El emeği göz nuru.", 90, 3, 1),
			new DeriZırh("Ayı postundan zırh", "Bu zırh için 3 kişi öldü. +3 vicdansızlık", 150, 7, 3),
			new DeriZırh("Yamalı zırh", "Oradan buradan toplanmış zırh.+4 karmaşıklık", 40, 2, 2) };
	static DemirZırh[] demirZırhlar = { new DemirZırh("Gümüş zırh", "", 180, 3, 1),
			new DemirZırh("Altın zırh", "Göz kamaştıran zırh", 400, 14, 9),
			new DemirZırh("Bor zırh", "Asıl gücü 2023'te ortaya çıkacak. +9 gizem", 600, 8, 12) };
	static ElektrikliZırh[] elektrikliZırhlar = {
			new ElektrikliZırh("Yüksek voltajlı zırh", "Cızzt cızzt... +1 V", 180, 3, 1),
			new ElektrikliZırh("Gauss zırhı", "∫E*dA. +9 fizik", 400, 14, 9),
			new ElektrikliZırh("Tesla zırhı", "Eller kadir kıymet bilmez. +4 değer", 600, 8, 12) };

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner girdi = new Scanner(System.in);
		SecureRandom r = new SecureRandom();

		Canavar canavar = new Canavar();

		int seçim = r.nextInt(2);

		switch (seçim) {
		case 0:
			canavar = new Canavar("Buz Ruhu", 12, kılıçlar[r.nextInt(2)], deriZırhlar[r.nextInt(2)]);
			break;
		case 2:
			canavar = new Canavar("Buz Ruhu", 12, yaylar[r.nextInt(2)], demirZırhlar[r.nextInt(2)]);
			break;
		case 1:
			canavar = new Canavar("Buz Ruhu", 12, baltalar[r.nextInt(2)], elektrikliZırhlar[r.nextInt(2)]);
			break;

		default:
			break;
		}
		System.out.println(seçim);
		System.out.println(canavar);

		Canavar canavar1 = new Canavar();

		seçim = r.nextInt(2);

		switch (seçim) {
		case 0:
			canavar1 = new Canavar("Allahsız Buğra", 17, kılıçlar[r.nextInt(2)], deriZırhlar[r.nextInt(2)]);
			break;
		case 2:
			canavar1 = new Canavar("Allahsız Buğra", 17, yaylar[r.nextInt(2)], demirZırhlar[r.nextInt(2)]);
			break;
		case 1:
			canavar1 = new Canavar("Allahsız Buğra", 17, baltalar[r.nextInt(2)], elektrikliZırhlar[r.nextInt(2)]);
			break;

		default:
			break;
		}
		System.out.println(seçim);
		System.out.println(canavar1);

		Canavar canavar2 = new Canavar();

		seçim = r.nextInt(2);

		switch (seçim) {
		case 0:
			canavar2 = new Canavar("Artist Dayı", 20, kılıçlar[r.nextInt(2)], deriZırhlar[r.nextInt(2)]);
			break;
		case 2:
			canavar2 = new Canavar("Artist Dayı", 20, yaylar[r.nextInt(2)], demirZırhlar[r.nextInt(2)]);
			break;
		case 1:
			canavar2 = new Canavar("Artist Dayı", 20, baltalar[r.nextInt(2)], elektrikliZırhlar[r.nextInt(2)]);
			break;

		default:
			break;
		}
		System.out.println(seçim);
		System.out.println(canavar2);


	}

}

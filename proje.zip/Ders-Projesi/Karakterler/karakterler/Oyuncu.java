package karakterler;

public class Oyuncu {

}

package karakterler;

import item.*;

public class Canavar extends Karakter{

	private int hasar;
	Silahlar silah;
	Z�rh z�rh;
	public Canavar(String isim, int hasar, Silahlar silah, Z�rh z�rh) {
		super(isim);
		this.hasar = hasar;
		this.silah = silah;
		this.z�rh = z�rh;
	}
	public Canavar(String isim, int hasar, Silahlar silah) {
		super(isim);
		this.hasar = hasar;
		this.silah = silah;
	}
	public Canavar(String isim, int hasar,  Z�rh z�rh) {
		super(isim);
		this.hasar = hasar;
		this.z�rh = z�rh;
	}
	
	public Canavar(String isim, int hasar) {
		super(isim);
		this.hasar = hasar;
		
	}
	public Canavar() {


	}

	public int getHasar() {
		return hasar;
	}

	public void setHasar(int hasar) {
		this.hasar = hasar;
	}

	public Silahlar getSilah() {
		return silah;
	}

	public void setSilah(Silahlar silah) {
		this.silah = silah;
	}

	public Z�rh getZ�rh() {
		return z�rh;
	}

	public void setZ�rh(Z�rh z�rh) {
		this.z�rh = z�rh;
	}
	
	@Override
	public String toString() {
		return "Canavar ["+"isim="+super.getIsim() +" hasar=" + hasar + ", silah=" + silah + ", z�rh=" + z�rh + "]";
	}
	
	
	
	
	
	
	
}

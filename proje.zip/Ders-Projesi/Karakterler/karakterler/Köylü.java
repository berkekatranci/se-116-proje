package karakterler;

public class K�yl� {

}

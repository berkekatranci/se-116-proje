package karakterler;

public abstract class Karakter {

	private String isim;
	private int can;
	public Karakter(String isim) {
		super();
		this.isim = isim;
		this.can = 100;
	}
	public String getIsim() {
		return isim;
	}
	public void setIsim(String isim) {
		this.isim = isim;
	}
	public int getCan() {
		return can;
	}
	public void setCan(int can) {
		this.can = can;
	}
	public Karakter() {
		super();
	}
	
	
	
}
